/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QComboBox *comboBox;
    QWidget *XYZ_widget;
    QLabel *l9_;
    QScrollBar *bar9;
    QLineEdit *l9;
    QLabel *l10_;
    QScrollBar *bar10;
    QLineEdit *l10;
    QLabel *l11_;
    QScrollBar *bar11;
    QLineEdit *l11;
    QLabel *label_14;
    QWidget *RGB_widget;
    QLabel *label_5;
    QLabel *label_4;
    QScrollBar *bar6;
    QLineEdit *l7;
    QLineEdit *l6;
    QLabel *label_6;
    QLineEdit *l5;
    QScrollBar *bar7;
    QScrollBar *bar5;
    QLabel *label_13;
    QWidget *LAB_widget;
    QScrollBar *bar14;
    QLabel *label_15;
    QLineEdit *l14;
    QLabel *label_9;
    QLineEdit *l15;
    QScrollBar *bar15;
    QLabel *label_7;
    QLineEdit *l13;
    QLabel *label_8;
    QScrollBar *bar13;
    QWidget *HSV_widget;
    QScrollBar *bar18;
    QLabel *label_16;
    QLineEdit *l18;
    QLabel *label_10;
    QLineEdit *l19;
    QScrollBar *bar19;
    QLabel *label_11;
    QLineEdit *l17;
    QLabel *label_17;
    QScrollBar *bar17;
    QWidget *HSL_widget;
    QScrollBar *bar21;
    QLabel *label_18;
    QLineEdit *l21;
    QLabel *label_19;
    QLineEdit *l22;
    QScrollBar *bar22;
    QLabel *label_20;
    QLineEdit *l20;
    QLabel *label_21;
    QScrollBar *bar20;
    QLineEdit *lineEdit;
    QWidget *CMYK_widget;
    QLineEdit *l4;
    QLineEdit *l1;
    QScrollBar *bar4;
    QLabel *l2_;
    QLabel *l1_;
    QScrollBar *bar2;
    QLabel *l4_;
    QScrollBar *bar1;
    QLabel *label_12;
    QLineEdit *l3;
    QScrollBar *bar3;
    QLineEdit *l2;
    QLabel *l3_;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(827, 474);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 20, 131, 41));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(200, 10, 151, 21));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        label_2->setFont(font);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(200, 40, 131, 21));
        comboBox = new QComboBox(centralwidget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(390, 40, 131, 24));
        XYZ_widget = new QWidget(centralwidget);
        XYZ_widget->setObjectName(QString::fromUtf8("XYZ_widget"));
        XYZ_widget->setGeometry(QRect(280, 280, 261, 181));
        l9_ = new QLabel(XYZ_widget);
        l9_->setObjectName(QString::fromUtf8("l9_"));
        l9_->setGeometry(QRect(10, 50, 21, 16));
        bar9 = new QScrollBar(XYZ_widget);
        bar9->setObjectName(QString::fromUtf8("bar9"));
        bar9->setGeometry(QRect(30, 50, 131, 16));
        bar9->setMaximum(95);
        bar9->setOrientation(Qt::Horizontal);
        l9 = new QLineEdit(XYZ_widget);
        l9->setObjectName(QString::fromUtf8("l9"));
        l9->setGeometry(QRect(170, 50, 71, 21));
        l9->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        l10_ = new QLabel(XYZ_widget);
        l10_->setObjectName(QString::fromUtf8("l10_"));
        l10_->setGeometry(QRect(10, 80, 21, 16));
        bar10 = new QScrollBar(XYZ_widget);
        bar10->setObjectName(QString::fromUtf8("bar10"));
        bar10->setGeometry(QRect(30, 80, 131, 16));
        bar10->setMaximum(100);
        bar10->setOrientation(Qt::Horizontal);
        l10 = new QLineEdit(XYZ_widget);
        l10->setObjectName(QString::fromUtf8("l10"));
        l10->setGeometry(QRect(170, 80, 71, 20));
        l10->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        l11_ = new QLabel(XYZ_widget);
        l11_->setObjectName(QString::fromUtf8("l11_"));
        l11_->setGeometry(QRect(10, 110, 21, 16));
        bar11 = new QScrollBar(XYZ_widget);
        bar11->setObjectName(QString::fromUtf8("bar11"));
        bar11->setGeometry(QRect(30, 110, 131, 16));
        bar11->setMaximum(108);
        bar11->setOrientation(Qt::Horizontal);
        l11 = new QLineEdit(XYZ_widget);
        l11->setObjectName(QString::fromUtf8("l11"));
        l11->setGeometry(QRect(170, 110, 71, 21));
        l11->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        label_14 = new QLabel(XYZ_widget);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(10, 20, 21, 16));
        RGB_widget = new QWidget(centralwidget);
        RGB_widget->setObjectName(QString::fromUtf8("RGB_widget"));
        RGB_widget->setGeometry(QRect(10, 90, 261, 181));
        label_5 = new QLabel(RGB_widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 80, 16, 20));
        label_4 = new QLabel(RGB_widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 50, 16, 20));
        bar6 = new QScrollBar(RGB_widget);
        bar6->setObjectName(QString::fromUtf8("bar6"));
        bar6->setGeometry(QRect(30, 80, 131, 16));
        bar6->setMaximum(255);
        bar6->setOrientation(Qt::Horizontal);
        l7 = new QLineEdit(RGB_widget);
        l7->setObjectName(QString::fromUtf8("l7"));
        l7->setGeometry(QRect(170, 110, 71, 21));
        l7->setStyleSheet(QString::fromUtf8("background-color:transparent\n"
""));
        l6 = new QLineEdit(RGB_widget);
        l6->setObjectName(QString::fromUtf8("l6"));
        l6->setGeometry(QRect(170, 80, 71, 21));
        l6->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        label_6 = new QLabel(RGB_widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 110, 16, 16));
        l5 = new QLineEdit(RGB_widget);
        l5->setObjectName(QString::fromUtf8("l5"));
        l5->setGeometry(QRect(170, 50, 71, 21));
        l5->setLayoutDirection(Qt::LeftToRight);
        l5->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        bar7 = new QScrollBar(RGB_widget);
        bar7->setObjectName(QString::fromUtf8("bar7"));
        bar7->setGeometry(QRect(30, 110, 131, 16));
        bar7->setMaximum(255);
        bar7->setOrientation(Qt::Horizontal);
        bar5 = new QScrollBar(RGB_widget);
        bar5->setObjectName(QString::fromUtf8("bar5"));
        bar5->setGeometry(QRect(30, 50, 131, 16));
        bar5->setStyleSheet(QString::fromUtf8(""));
        bar5->setMaximum(255);
        bar5->setSingleStep(1);
        bar5->setOrientation(Qt::Horizontal);
        label_13 = new QLabel(RGB_widget);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(10, 19, 28, 20));
        LAB_widget = new QWidget(centralwidget);
        LAB_widget->setObjectName(QString::fromUtf8("LAB_widget"));
        LAB_widget->setGeometry(QRect(280, 90, 261, 181));
        bar14 = new QScrollBar(LAB_widget);
        bar14->setObjectName(QString::fromUtf8("bar14"));
        bar14->setGeometry(QRect(30, 80, 131, 16));
        bar14->setMinimum(-128);
        bar14->setMaximum(128);
        bar14->setOrientation(Qt::Horizontal);
        label_15 = new QLabel(LAB_widget);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(10, 20, 28, 20));
        l14 = new QLineEdit(LAB_widget);
        l14->setObjectName(QString::fromUtf8("l14"));
        l14->setGeometry(QRect(170, 80, 71, 21));
        l14->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        label_9 = new QLabel(LAB_widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(10, 80, 16, 20));
        l15 = new QLineEdit(LAB_widget);
        l15->setObjectName(QString::fromUtf8("l15"));
        l15->setGeometry(QRect(170, 110, 71, 21));
        l15->setStyleSheet(QString::fromUtf8("background-color:transparent\n"
""));
        bar15 = new QScrollBar(LAB_widget);
        bar15->setObjectName(QString::fromUtf8("bar15"));
        bar15->setGeometry(QRect(30, 110, 131, 17));
        bar15->setMinimum(-128);
        bar15->setMaximum(128);
        bar15->setOrientation(Qt::Horizontal);
        label_7 = new QLabel(LAB_widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 50, 16, 20));
        l13 = new QLineEdit(LAB_widget);
        l13->setObjectName(QString::fromUtf8("l13"));
        l13->setGeometry(QRect(170, 50, 71, 21));
        l13->setLayoutDirection(Qt::LeftToRight);
        l13->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        label_8 = new QLabel(LAB_widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(10, 110, 16, 16));
        bar13 = new QScrollBar(LAB_widget);
        bar13->setObjectName(QString::fromUtf8("bar13"));
        bar13->setGeometry(QRect(30, 50, 131, 16));
        bar13->setStyleSheet(QString::fromUtf8(""));
        bar13->setMaximum(100);
        bar13->setOrientation(Qt::Horizontal);
        HSV_widget = new QWidget(centralwidget);
        HSV_widget->setObjectName(QString::fromUtf8("HSV_widget"));
        HSV_widget->setGeometry(QRect(10, 280, 261, 151));
        bar18 = new QScrollBar(HSV_widget);
        bar18->setObjectName(QString::fromUtf8("bar18"));
        bar18->setGeometry(QRect(30, 80, 131, 16));
        bar18->setMinimum(0);
        bar18->setMaximum(100);
        bar18->setOrientation(Qt::Horizontal);
        label_16 = new QLabel(HSV_widget);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(10, 20, 28, 20));
        l18 = new QLineEdit(HSV_widget);
        l18->setObjectName(QString::fromUtf8("l18"));
        l18->setGeometry(QRect(170, 80, 71, 21));
        l18->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        label_10 = new QLabel(HSV_widget);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(10, 80, 16, 20));
        l19 = new QLineEdit(HSV_widget);
        l19->setObjectName(QString::fromUtf8("l19"));
        l19->setGeometry(QRect(170, 110, 71, 21));
        l19->setStyleSheet(QString::fromUtf8("background-color:transparent\n"
""));
        bar19 = new QScrollBar(HSV_widget);
        bar19->setObjectName(QString::fromUtf8("bar19"));
        bar19->setGeometry(QRect(30, 110, 131, 17));
        bar19->setMinimum(0);
        bar19->setMaximum(100);
        bar19->setOrientation(Qt::Horizontal);
        label_11 = new QLabel(HSV_widget);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(10, 50, 16, 20));
        l17 = new QLineEdit(HSV_widget);
        l17->setObjectName(QString::fromUtf8("l17"));
        l17->setGeometry(QRect(170, 50, 71, 21));
        l17->setLayoutDirection(Qt::LeftToRight);
        l17->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        label_17 = new QLabel(HSV_widget);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(10, 110, 16, 16));
        bar17 = new QScrollBar(HSV_widget);
        bar17->setObjectName(QString::fromUtf8("bar17"));
        bar17->setGeometry(QRect(30, 50, 131, 16));
        bar17->setStyleSheet(QString::fromUtf8(""));
        bar17->setMaximum(360);
        bar17->setOrientation(Qt::Horizontal);
        HSL_widget = new QWidget(centralwidget);
        HSL_widget->setObjectName(QString::fromUtf8("HSL_widget"));
        HSL_widget->setGeometry(QRect(550, 280, 261, 151));
        bar21 = new QScrollBar(HSL_widget);
        bar21->setObjectName(QString::fromUtf8("bar21"));
        bar21->setGeometry(QRect(30, 80, 131, 16));
        bar21->setMinimum(0);
        bar21->setMaximum(100);
        bar21->setOrientation(Qt::Horizontal);
        label_18 = new QLabel(HSL_widget);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(10, 20, 28, 20));
        l21 = new QLineEdit(HSL_widget);
        l21->setObjectName(QString::fromUtf8("l21"));
        l21->setGeometry(QRect(170, 80, 71, 21));
        l21->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        label_19 = new QLabel(HSL_widget);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(10, 80, 16, 20));
        l22 = new QLineEdit(HSL_widget);
        l22->setObjectName(QString::fromUtf8("l22"));
        l22->setGeometry(QRect(170, 110, 71, 21));
        l22->setStyleSheet(QString::fromUtf8("background-color:transparent\n"
""));
        bar22 = new QScrollBar(HSL_widget);
        bar22->setObjectName(QString::fromUtf8("bar22"));
        bar22->setGeometry(QRect(30, 110, 131, 17));
        bar22->setMinimum(0);
        bar22->setMaximum(100);
        bar22->setOrientation(Qt::Horizontal);
        label_20 = new QLabel(HSL_widget);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(10, 50, 16, 20));
        l20 = new QLineEdit(HSL_widget);
        l20->setObjectName(QString::fromUtf8("l20"));
        l20->setGeometry(QRect(170, 50, 71, 21));
        l20->setLayoutDirection(Qt::LeftToRight);
        l20->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        label_21 = new QLabel(HSL_widget);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(10, 110, 16, 16));
        bar20 = new QScrollBar(HSL_widget);
        bar20->setObjectName(QString::fromUtf8("bar20"));
        bar20->setGeometry(QRect(30, 50, 131, 16));
        bar20->setStyleSheet(QString::fromUtf8(""));
        bar20->setMaximum(360);
        bar20->setOrientation(Qt::Horizontal);
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(30, 70, 113, 24));
        CMYK_widget = new QWidget(centralwidget);
        CMYK_widget->setObjectName(QString::fromUtf8("CMYK_widget"));
        CMYK_widget->setGeometry(QRect(550, 90, 261, 181));
        l4 = new QLineEdit(CMYK_widget);
        l4->setObjectName(QString::fromUtf8("l4"));
        l4->setGeometry(QRect(170, 140, 71, 21));
        l4->setLayoutDirection(Qt::LeftToRight);
        l4->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        l1 = new QLineEdit(CMYK_widget);
        l1->setObjectName(QString::fromUtf8("l1"));
        l1->setGeometry(QRect(170, 50, 71, 21));
        l1->setLayoutDirection(Qt::LeftToRight);
        l1->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        bar4 = new QScrollBar(CMYK_widget);
        bar4->setObjectName(QString::fromUtf8("bar4"));
        bar4->setGeometry(QRect(40, 140, 121, 16));
        bar4->setMaximum(100);
        bar4->setOrientation(Qt::Horizontal);
        l2_ = new QLabel(CMYK_widget);
        l2_->setObjectName(QString::fromUtf8("l2_"));
        l2_->setGeometry(QRect(20, 80, 16, 16));
        l1_ = new QLabel(CMYK_widget);
        l1_->setObjectName(QString::fromUtf8("l1_"));
        l1_->setGeometry(QRect(20, 50, 16, 16));
        bar2 = new QScrollBar(CMYK_widget);
        bar2->setObjectName(QString::fromUtf8("bar2"));
        bar2->setGeometry(QRect(40, 80, 121, 16));
        bar2->setMaximum(100);
        bar2->setOrientation(Qt::Horizontal);
        l4_ = new QLabel(CMYK_widget);
        l4_->setObjectName(QString::fromUtf8("l4_"));
        l4_->setGeometry(QRect(20, 140, 16, 16));
        bar1 = new QScrollBar(CMYK_widget);
        bar1->setObjectName(QString::fromUtf8("bar1"));
        bar1->setGeometry(QRect(40, 50, 121, 16));
        bar1->setMaximum(100);
        bar1->setOrientation(Qt::Horizontal);
        label_12 = new QLabel(CMYK_widget);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(20, 20, 33, 16));
        l3 = new QLineEdit(CMYK_widget);
        l3->setObjectName(QString::fromUtf8("l3"));
        l3->setGeometry(QRect(170, 110, 71, 21));
        l3->setLayoutDirection(Qt::LeftToRight);
        l3->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        bar3 = new QScrollBar(CMYK_widget);
        bar3->setObjectName(QString::fromUtf8("bar3"));
        bar3->setGeometry(QRect(40, 110, 121, 16));
        bar3->setMaximum(100);
        bar3->setOrientation(Qt::Horizontal);
        l2 = new QLineEdit(CMYK_widget);
        l2->setObjectName(QString::fromUtf8("l2"));
        l2->setGeometry(QRect(170, 80, 71, 21));
        l2->setLayoutDirection(Qt::LeftToRight);
        l2->setStyleSheet(QString::fromUtf8("background-color:transparent"));
        l3_ = new QLabel(CMYK_widget);
        l3_->setObjectName(QString::fromUtf8("l3_"));
        l3_->setGeometry(QRect(20, 110, 16, 16));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 827, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "\320\230\320\267\320\274\320\265\320\275\320\265\320\275\320\270\320\265 \321\206\320\262\320\265\321\202\320\260", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "\320\262\321\213\320\261\320\276\321\200 \321\206\320\262\320\265\321\202\320\260", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("MainWindow", "1.RGB-LAB-CMYK", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("MainWindow", "2.RGB-CMYK-HSL", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("MainWindow", "3.RGB-XYZ-LAB", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("MainWindow", "4.RGB-HSV-LAB", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("MainWindow", "5.CMYK-LAB-HSV", nullptr));
        comboBox->setItemText(5, QCoreApplication::translate("MainWindow", "6.CMYK-RGB-HSL", nullptr));
        comboBox->setItemText(6, QCoreApplication::translate("MainWindow", "7.CMYK-RGB-HSV", nullptr));
        comboBox->setItemText(7, QCoreApplication::translate("MainWindow", "8.RGB-XYZ-LAB", nullptr));
        comboBox->setItemText(8, QCoreApplication::translate("MainWindow", "9.CMYK-LAB-RGB", nullptr));
        comboBox->setItemText(9, QCoreApplication::translate("MainWindow", "10.XYZ-LAB-HSL", nullptr));
        comboBox->setItemText(10, QCoreApplication::translate("MainWindow", "11.XYZ-LAB-HSL", nullptr));
        comboBox->setItemText(11, QCoreApplication::translate("MainWindow", "12.RGB-XYZ-HSL", nullptr));
        comboBox->setItemText(12, QCoreApplication::translate("MainWindow", "13.RGB-XYZ-CMYK", nullptr));
        comboBox->setItemText(13, QCoreApplication::translate("MainWindow", "14.CMYK-LAB-XYZ", nullptr));
        comboBox->setItemText(14, QCoreApplication::translate("MainWindow", "15.RGB-CMYK-HSV", nullptr));
        comboBox->setItemText(15, QCoreApplication::translate("MainWindow", "16.CMYK-HSL-XYZ", nullptr));
        comboBox->setItemText(16, QCoreApplication::translate("MainWindow", "17.RGB-HSL-LAB", nullptr));
        comboBox->setItemText(17, QCoreApplication::translate("MainWindow", "18.CMYK-XYZ-RGB", nullptr));

        l9_->setText(QCoreApplication::translate("MainWindow", "X:", nullptr));
        l10_->setText(QCoreApplication::translate("MainWindow", "Y:", nullptr));
        l11_->setText(QCoreApplication::translate("MainWindow", "Z:", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "XYZ", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "G:", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "R:", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "B:", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "RGB", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "LAB", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "A:", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "L:", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "B:", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "HSV", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "S:", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "H:", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "V:", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "HSL", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "S:", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "H:", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "L:", nullptr));
        l2_->setText(QCoreApplication::translate("MainWindow", "M:", nullptr));
        l1_->setText(QCoreApplication::translate("MainWindow", "C:", nullptr));
        l4_->setText(QCoreApplication::translate("MainWindow", "K:", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "CMYK", nullptr));
        l3_->setText(QCoreApplication::translate("MainWindow", "Y:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
